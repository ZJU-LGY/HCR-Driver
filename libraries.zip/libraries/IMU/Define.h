//----------------------------------------------------------------------------
//    프로그램명 	: DEFINE
//
//    만든이     	: Made by Baram ( chcbaram@paran.com )
//
//    날  짜     : 
//    
//    최종 수정  	: 
//
//    MPU_Type	: 
//
//    파일명     	: DEFINE.h
//----------------------------------------------------------------------------
#ifndef _DEFINE_H_
#define _DEFINE_H_

#include <inttypes.h>
#include <Arduino.h> 



#define ROLL		0
#define PITCH		1
#define YAW			2



#endif